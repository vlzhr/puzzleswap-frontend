# puzzle-swap

## Starting project

- Clone

```bash
    git clone https://github.com/vlzhr/puzzleswap-frontend
    cd puzzleswap-frontend
```

- Install dependencies

```bash
    yarn
```

- Build application

```bash
  npm run build
```

- Run the application frontend (from .)

```bash
  npm run start 
```